Android --> java-->com.example.myapplication(//yourfilename)

Res -->menu -->main.xml

Res -->values -->dimens.xml