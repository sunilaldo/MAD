package com.example.myapplication99;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

public class MainActivity extends AppCompatActivity {

    EditText num1, num2;
    Button addButton;
    TextView resultText;
    private static final String CHANNEL_ID = "addition_notification";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);
        addButton = findViewById(R.id.addButton);
        resultText = findViewById(R.id.resultText);

        // Button Click Listener
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNumbers();
            }
        });

        // Create notification channel for Android 8.0+
        createNotificationChannel();
    }

    private void addNumbers() {
        String n1 = num1.getText().toString();
        String n2 = num2.getText().toString();

        if (!n1.isEmpty() && !n2.isEmpty()) {
            int sum = Integer.parseInt(n1) + Integer.parseInt(n2);
            resultText.setText("Sum of Two No is: " + sum);

            // Show a notification
            showNotification(sum);
        } else {
            resultText.setText("Please enter both numbers.");
        }
    }

    private void showNotification(int sum) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("Addition Result")
                .setContentText("The sum is: " + sum)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify(1, builder.build());
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Addition Notification";
            String description = "Channel for Addition result notifications";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }
}
